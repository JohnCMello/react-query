export const queryKeys = {
  treatments: 'treatments',
  appointments: 'appointments',
  user: 'user',
  staff: 'staff',
};
