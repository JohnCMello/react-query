import { useStaff } from '../hooks/useStaff';

test('filter staff', async () => {
  // the magic happens here
});
