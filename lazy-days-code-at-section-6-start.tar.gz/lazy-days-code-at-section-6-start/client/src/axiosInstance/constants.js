export const baseUrl = 'http://localhost:3030';
export const baseImageUrl = `${baseUrl}/images`;
